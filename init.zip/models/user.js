const mongoose = require("mongoose");
const Schema = mongoose.Schema;
// const passportLocalMongoose = require("passport-local-mongoose");
const passportLocalMongoose = require("passport-local-mongoose").default || require("passport-local-mongoose");

const userSchema = new Schema ({
    email:{
        type: String,
        required: true,
    },
});


// Yeh apne app hashing, salting,user and password sab kr dega 
userSchema.plugin(passportLocalMongoose);

module.exports = mongoose.model('User', userSchema);