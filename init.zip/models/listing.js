// const mongoose = require("mongoose");
// const Schema = mongoose.Schema;

// const listingSchema = new Schema({
//     title: {
//         type: String,
//         required: true,
//     },
//     description: String,
//     image: {
//         type:String,
//         default: "https://images.unsplash.com/photo-1590523278191-995cbcda646b?q=80&w=735&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
//         set:(v)=> v=== ""? 
//         "https://images.unsplash.com/photo-1590523278191-995cbcda646b?q=80&w=735&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
//         :v,
             
//     },
//     price: Number,
//     location: String,
//     country: String,
// });

// const Listing= mongoose.model("Listing", listingSchema);
// module.exports = Listing;

// const mongoose = require("mongoose");
// const Schema = mongoose.Schema;

// const listingSchema = new Schema({
//   title: {
//     type: String,
//     required: true,
//   },
//   description: String,
//   // Change image from a String to an Object
//   image: {
//     filename: String,
//     url: {
//       type: String,
//       default: "https://images.unsplash.com/photo-1590523278191-995cbcda646b?q=80&w=735&auto=format&fit=crop",
//       set: (v) => v === "" 
//         ? "https://images.unsplash.com/photo-1590523278191-995cbcda646b?q=80&w=735&auto=format&fit=crop" 
//         : v,
//     },
//   },
//   price: Number,
//   location: String,
//   country: String,
// });

// const Listing = mongoose.model("Listing", listingSchema);
// module.exports = Listing;

const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const Review = require("./review.js");
const { required } = require("joi");

const listingSchema = new Schema({
  title: {
    type: String,
    required: true,
  },

  description: String,

  image: {
  url: {
    type: String,
    default: "https://images.unsplash.com/photo-1590523278191-995cbcda646b?q=80&w=735&auto=format&fit=crop",
    set: (v) => v === "" ? "https://images.unsplash.com/photo-1590523278191-995cbcda646b?q=80&w=735&auto=format&fit=crop" : v,
  },
  filename: {
    type: String,
    default: "listingimage",
  },
},

  price: Number,
  location: String,
  country: String,
  reviews: [{
    type: Schema.Types.ObjectId,
    ref: "Review",
  },
],
  owner: {
    type: Schema.Types.ObjectId,
    ref: "User",
  },
  geometry: {
    type: {
        type: String, 
        enum: ['Point'], 
        required: true
    },
    coordinates: {
        type: [Number],
        required: true
    }
}
});

listingSchema.post("findOneAndDelete",async(listing)=>{
  if(listing){
    await Review.deleteMany({_id: {$in : listing.reviews}});
  }
})

const Listing = mongoose.model("Listing", listingSchema);
module.exports = Listing;