const express = require("express");
const router = express.Router();
const wrapAsync= require("../utils/wrapAsync.js");
const {isLoggedIn} = require("../middleware.js");
const {isOwner, validateListing} = require("../middleware.js");
const listingController = require("../controllers/listings.js");
const multer  = require('multer');
const {storage} = require("../cloudConfig.js");
const upload = multer({ storage });


router.route("/")
// INDEX
.get(wrapAsync(listingController.index))
// CREATE
.post(isLoggedIn,upload.single('listing[image][url]'),validateListing,wrapAsync(listingController.create));


// New route
router.get("/new", isLoggedIn,listingController.renderNewForm);


router.route("/:id")
// SHOW
.get(wrapAsync(listingController.showListing))
// UPDATE
.put( isLoggedIn,isOwner,upload.single('listing[image][url]'),validateListing,wrapAsync(listingController.update))
// DELETE
.delete(isLoggedIn,isOwner, wrapAsync(listingController.delete));

// Edit route 
router.get("/:id/edit",isLoggedIn,isOwner, wrapAsync(listingController.edit));



module.exports = router;